#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  pid_t childpid = 0;
  int i, n;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s processes\n", argv[0]);  
  }
  
  n = 5;  // numero a ser inserido
      
  for (i = 1; i < n+1; i++) {
    if (childpid = fork()) {
      fprintf(stderr, "i:%d process ID:%ld parent ID:%ld child ID:%ld\n", i, (long)getpid(), (long)getppid(), (long)childpid);
    
    }
    else{
      return 0;
    }
  }
}